#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 22 17:20:16 2023

@author: dai
"""

class Players:
    def __init__(self, pid='', pname='', spec='', charges=0, team=''):
        self.__pid=pid
        self.__pname=pname
        self.__spec=spec
        self.__charges=charges
        self.__team=team
        
    #returns string for printing   
    def __str__(self):
        print("-"*50)
        str1=f"""
        pid:{self.__pid} 
        Name:{self.__pname} 
        Specialization:{self.__spec}
        Charges:{self.__charges}
        Team:{self.__team}
        """
        return str1
    
    #setter methods
    def set_pid(self, pid ):
        self.__pid=pid
        
    def set_pname(self, pname ):
        self.__panme=pname
        
    def set_spec(self, spec ):
        self.__spec=spec 
    
    def set_team(self, team ):
        self.__team=team 
        
    def set_charges(self, charges ):
        self.__charges=charges 
        
    #getter methods  
    def get_pid(self):
        return self.__pid
        
    def get_pname(self):
        return self.__pname
        
    def get_spec(self):
        return self.__spec
    
    def get_team(self):
        return self.__team
        
    def get_charges(self):
        return self.__charges
 
    def get_line(self):
        str1=f"{self.__pid}|{self.__pname}|{self.__spec}|{self.__charges}|{self.__team}"
        return str1