from player_func import *


if __name__=="__main__":
    
    choice="0"
    while choice!="":
        choice=input("""
        A. Display Total charges teamwise
        B. Change team
        C. Delete the team
        D. Modify charges by Id  
        E. Add new Player
        F. Display All Players
        G. Pattern checking if start with 2 and ends with "g"
        H. Display with skill
        I. Delete player
        Q. Quit            
        Enter A choice: """)
        choice=choice.lower()
        match choice:
            case "a":
                status=desplaytotalcharges()
            case "b":
                pid=input("Enter player ID :")
                team=input("Enter new team :")
                status=changeteam(pid, team)
                if status==1:
                    print("Successful")
                else:
                    print("Not found")
            case "c":
                pteam=input("Enter new team :")
                status=deleteteam(pteam)
                if status==1:
                    print("Successful")
                else:
                    print("Not found")
            case "d":
                pid=input("Enter player ID :")
                charges=int(input("Enter player charges :"))
                status=modifychargesbyid(pid, charges)
                if status==1:
                    print("Successful")
                else:
                    print("Not found")
            case "e":
                pid=input("Enter player ID :")
                pname=input("Enter player name :")
                spec=input("Enter player specilizaton :")
                charges=int(input("Enter player charges :"))
                team=input("Enter player Team name :")
                status= createnewplayer(pid, pname,spec, charges, team)
                print(status)
            case "f":
                status= displayAll()
            case "g":
                status= pattercheck()
                if status==1:
                    print("Successful")
                else:
                    print("Not found")
            case "h":
                skill= input("Enter Specification to search:")
                status= skilldisplay(skill)
                if status==1:
                    print("Successful")
                else:
                    print("Not found")
            case "i":
                pid=input("Enter player ID :")
                status= deleteplayer(pid)
                if status==1:
                    print("Successful")
                else:
                    print("Not found")
            case "q":
                saveTxt()
                print("Quit")
                break
                        
            case other:
                saveTxt()
                print("Enter Valid Choice")
            
                
