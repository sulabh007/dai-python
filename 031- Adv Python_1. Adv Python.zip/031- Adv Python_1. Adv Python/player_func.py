#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 22 17:21:37 2023

@author: dai
"""

import re
from player_class import *

player_details=[]

#Reads file named player.txt

with open("player.txt","r") as fh:
    for line in fh:
        lst=line.split("|")
        player1=Players(lst[0], lst[1], lst[2], lst[3], lst[4])
        player_details.append(player1)

#Writes to file pkayer.txt       
def saveTxt():
    with open("player.txt","w") as fh:
        for player in player_details:
            line=player.get_line()
            fh.write(line)
        
#Creates new player with input from user
def createnewplayer(pid, pname, spec, charges, team):
    #n is object of class Player
    player1=Players(pid, pname.capitalize(), spec.capitalize(), charges, team.capitalize())
    player_details.append(player1)
    return player1

#Moidifies charges of player by player id
def modifychargesbyid(pid, charges):
    for player in player_details:
        print(player.get_line())
        #ids is id of player
        ids=player.get_pid()
        if ids==pid:
            
            player.set_charges(charges)
            return 1
    
    return 2

#dispalyes charges of team    
def desplaytotalcharges():
    #dict1 stores value of team and charges
    dict1={}
    for player in player_details:
        team=player.get_team().strip("\n")
        if dict1.get(team):    
            dict1[team]=int(dict1[team])+int(player.get_charges())
        else:
            dict1.setdefault(team, player.get_charges())
    for i, j in dict1.items():
        print(f"{i}------>{j}")
    return 1

#Removes team of player by player id     
def deleteteam(pteam):
    success_flag=-1
    for player in player_details:
        team=player.get_team().strip("\n")
        if pteam==team:
            player_details.remove(player)
            success_flag=1
    return success_flag

#changes team of a player
def changeteam(pid, team):
    
    for player in player_details:
        ids=player.get_pid()
        if ids==pid:
            player.set_team(team)
            return 1
    else: 
        return 2
    

def displayAll():
    for player in player_details:
        print("\t"+"_"*50)
        print("\t"+player.get_line().strip("\n"))
        print("\t"+"_"*50)

#it checks for given pattern and prints players matching pattern
def pattercheck():
    regex=r"^2.*g$"
    success_flag=-1   
    for player in player_details:
        
        str1=player.get_line().strip("\n")
        n=re.match(regex, str1)
        if n:
            print(str1)
            success_flag=1
    return success_flag      
 
#Displays player with given skill           
def skilldisplay(skill):
    
    success_flag=-1
    for player in player_details:
        if player.get_spec()==skill.capitalize():
            print(player.get_line())
            success_flag=1
    return success_flag
 
def deleteplayer(pid):
        
        for player in player_details:
            ids=player.get_pid()
            if ids==pid:
                player_details.remove(player)
                return 1 
        return 2
    
